conn = sqlite3.connect('market.db')
x = [['hello'],[]]
c = conn.cursor()    
c.execute(""" CREATE TABLE IF NOT EXIST record_stock_daily 
                (prod_name VARCHAR(100),
                date DATE,
                stock_num INT,
                stock_unit VARCHAR(100)) 
                """)
c.execute("""INSERT INTO record_stock_daily 
                VALUES {}, {}, {}, {}""".format(row[0],date_stamp ,row[1],row[2]))

conn.commit()